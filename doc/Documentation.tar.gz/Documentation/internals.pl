# LaTeX2HTML 2K.1beta (1.48)
# Associate internals original text with physical files.


$key = q/graphtable/;
$ref_files{$key} = "$dir".q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/graphcommands/;
$ref_files{$key} = "$dir".q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/ShapeAndColor/;
$ref_files{$key} = "$dir".q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/1d_diff_LB/;
$ref_files{$key} = "$dir".q|node11.html|; 
$noresave{$key} = "$nosave";

$key = q/install/;
$ref_files{$key} = "$dir".q|node10.html|; 
$noresave{$key} = "$nosave";

$key = q/fig1/;
$ref_files{$key} = "$dir".q|node7.html|; 
$noresave{$key} = "$nosave";

1;

